<?php
echo "<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <title>Selecciona una película</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap');

        body {
            font-family: 'Cinzel', serif;
            background-color: #2D1E2F;
            color: gold;
            text-align: center;
            padding: 20px;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .movie {
            background-color: #3B2929;
            border: 2px solid gold;
            border-radius: 10px;
            padding: 10px;
            transition: transform 0.3s, box-shadow 0.3s;
            box-shadow: 0px 0px 15px gold;
        }

        .movie a {
            text-decoration: none;
            color: gold;
        }

        .movie img {
            width: 200px;
            height: 300px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(255, 215, 0, 0.5);
        }

        .movie p {
            margin-top: 10px;
            font-size: 1.2em;
        }

        .movie:hover {
            transform: scale(1.08);
            box-shadow: 0 10px 20px rgba(255, 215, 0, 0.5);
        }

        .button {
            background-color: gold;
            color: #3B2929;
            padding: 10px;
            border-radius: 5px;
            font-size: 1.2em;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .button:hover {
            background-color: #B8860B;
        }
    </style>
</head>
<body>
    <h1>⚡ Selecciona una película mágica ⚡</h1>
    <div class='container'>";

$peliculas = [
    "Harry Potter y la Piedra Filosofal" => "harrypotter1.jpg",
    "Harry Potter y la Cámara Secreta" => "harrypotter2.jpg",
    "Harry Potter y el Prisionero de Azkaban" => "harrypotter3.jpg",
    "Harry Potter y el Cáliz de Fuego" => "harrypotter4.jpg",
    "Harry Potter y la Orden del Fénix" => "harrypotter5.jpg",
    "Harry Potter y el Misterio del Príncipe" => "harrypotter6.jpg",
    "Harry Potter y las Reliquias de la Muerte (Parte 1)" => "harrypotter7.jpg",
    "Harry Potter y las Reliquias de la Muerte (Parte 2)" => "harrypotter8.jpg"
];

foreach ($peliculas as $titulo => $imagen) {
    echo "<div class='movie'><a href='ver_comentarios.php?pelicula=" . urlencode($titulo) . "'><img src='$imagen' alt='$titulo'><p>$titulo</p></a></div>";
}

echo "</div><br>";
echo "<a href='comentario_peli.php' class='button'>📝 Escribir un comentario mágico</a>
</body>
</html>";
?>


