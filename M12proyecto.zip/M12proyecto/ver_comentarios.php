<?php
$conn = new mysqli("localhost", "harry", "potter", "m12base");

if ($conn->connect_error) {
    die("Conexión fallida");
}

$pelicula = $_GET['pelicula']; // Obtener la película seleccionada

echo "<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <title>Comentarios sobre $pelicula</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap');

        body {
            font-family: 'Cinzel', serif;
            background-color: #2D1E2F;
            color: gold;
            text-align: center;
            padding: 20px;
        }

        .container {
            background: #3B2929;
            padding: 20px;
            margin: auto;
            width: 60%;
            border-radius: 10px;
            border: 2px solid gold;
            box-shadow: 0px 0px 15px gold;
        }

        h2 {
            font-size: 2em;
            text-shadow: 2px 2px 10px gold;
        }

        .comment {
            background-color: #5A3A3A;
            border: 1px solid gold;
            border-radius: 5px;
            padding: 10px;
            margin: 10px 0;
            box-shadow: 0px 0px 8px gold;
        }

        .comment strong {
            color: gold;
        }

        .button {
            background-color: gold;
            color: #3B2929;
            padding: 10px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 1.2em;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .button:hover {
            background-color: #B8860B;
        }
    </style>
</head>
<body>
    <div class='container'>
        <h2>📜 Comentarios sobre " . htmlspecialchars($pelicula) . "</h2>";

$result = $conn->query("SELECT nombre_usuario, comentario FROM comentarios_hp WHERE pelicula='$pelicula'");

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='comment'><strong>" . htmlspecialchars($row["nombre_usuario"]) . "</strong>: " . htmlspecialchars($row["comentario"]) . "</div>";
    }
} else {
    echo "<p>No hay comentarios sobre esta película aún.</p>";
}

$conn->close();

echo "<br><a href='lista_pelis.php' class='button'>🔙 Volver a la lista de películas</a>
    </div>
</body>
</html>";
?>
