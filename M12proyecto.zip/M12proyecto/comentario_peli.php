<?php
$conn = new mysqli("localhost", "harry", "potter", "m12base");

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$pelicula = isset($_GET['pelicula']) ? $_GET['pelicula'] : '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "INSERT INTO comentarios_hp (nombre_usuario, pelicula, comentario) VALUES ('$_POST[nombre_usuario]', '$_POST[pelicula]', '$_POST[comentario]')";
    $conn->query($sql);
    
  }

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Escribe un comentario</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap');

        body {
            font-family: 'Cinzel', serif;
            background-color: #2D1E2F;
            color: gold;
            text-align: center;
            padding: 20px;
        }

        form {
            background: #3B2929;
            padding: 20px;
            margin: auto;
            width: 50%;
            box-shadow: 0px 0px 15px gold;
            border-radius: 10px;
            border: 2px solid gold;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 2px solid gold;
            border-radius: 5px;
            background: #5A3A3A;
            color: gold;
            font-family: 'Cinzel', serif;
        }

        button {
            background-color: gold;
            color: #3B2929;
            padding: 10px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-family: 'Cinzel', serif;
        }

        button:hover {
            background-color: #B8860B;
        }
    </style>
</head>
<body>
    <h2>📜 Escribe un comentario sobre "<?php echo htmlspecialchars($pelicula); ?>"</h2>
    <form method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre_usuario" required>
        
        <label>Película:</label>
        <input type="text" name="pelicula" required placeholder="Ej: Ponlo tal cual como sale si no no veras el comentario">

         <label>Comentario:</label>
        <textarea name="comentario" required></textarea>
        
        <button type="submit">Enviar</button>
    </form>

    <br>
    <a href="lista_pelis.php"><button>🔙 Volver a la lista de películas</button></a>
</body>
</html>

 



















